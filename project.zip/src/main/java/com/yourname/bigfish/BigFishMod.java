package com.yourname.bigfish;

import com.yourname.bigfish.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(BigFishMod.MOD_ID)
public class BigFishMod {
    public static final String MOD_ID = "bigfish";

    public BigFishMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
    }
}
