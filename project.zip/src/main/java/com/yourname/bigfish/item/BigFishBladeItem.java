package com.yourname.bigfish.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.particles.ParticleTypes;

import javax.annotation.Nullable;
import java.util.List;

public class BigFishBladeItem extends Item {

    public BigFishBladeItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!target.getLevel().isClientSide && attacker instanceof Player player) {
            target.kill(); 

            ServerLevel serverLevel = (ServerLevel) target.getLevel();
            serverLevel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, target.getX(), target.getY(), target.getZ(), 3, 0, 0, 0, 0);
            serverLevel.sendParticles(ParticleTypes.FLASH, target.getX(), target.getY() + 1, target.getZ(), 10, 0, 0, 0, 0);

            serverLevel.playSound(null, target.getX(), target.getY(), target.getZ(), 
								  SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.0F, 2.0F);

            player.sendSystemMessage(Component.literal("§c[大肥鱼之刃] §f已将 §e" + target.getName().getString() + " §f从物理世界抹除！"));
        }
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide) {
            ServerLevel serverLevel = (ServerLevel) level;

            AABB aabb = player.getBoundingBox().inflate(64.0D);
            List<Entity> entities = serverLevel.getEntitiesOfClass(Entity.class, aabb, 
				e -> e != player && !(e instanceof Player) && !e.isPassengerOfSameVehicle(player));

            int count = 0;
            for (Entity entity : entities) {
                entity.kill();
                serverLevel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, entity.getX(), entity.getY(), entity.getZ(), 1, 0, 0, 0, 0);
                count++;
            }

            serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(), 
								  SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 5.0F, 0.5F);

            player.sendSystemMessage(Component.literal("§b[大肥鱼之刃] §f全屏清场！共抹除 §c" + count + " §f个实体！"));
            player.getCooldowns().addCooldown(this, 200); 
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§6传说中深海大肥鱼的化身").withStyle(ChatFormatting.ITALIC));
        tooltip.add(Component.literal("§c左键：§f点谁谁死（物理超度）"));
        tooltip.add(Component.literal("§c右键：§f众生平等（全屏清场）"));
        tooltip.add(Component.literal("§8「真·吃白饭必备神器」"));
    }
}
