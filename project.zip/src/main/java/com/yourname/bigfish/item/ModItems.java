package com.yourname.bigfish.item;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "bigfish");

    public static final RegistryObject<Item> BIG_FISH_BLADE = ITEMS.register("big_fish_blade", BigFishBladeItem::new);
}
